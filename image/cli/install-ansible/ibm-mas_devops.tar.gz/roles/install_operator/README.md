install_operator
================

TODO: Summarize role

Role Variables
--------------

### custom_labels
List of comma separated key=value pairs for setting custom labels on instance specific resources.

- Optional
- Environment Variable: `CUSTOM_LABELS`
- Default Value: None


TODO: Finish documentation


Example Playbook
----------------

```yaml
TODO: Add example
```

License
-------

EPL-2.0
