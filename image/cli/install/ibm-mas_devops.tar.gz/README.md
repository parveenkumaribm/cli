# Ansible DevOps Collection for IBM Maximo Application Suite

## Documentation
[https://ibm-mas.github.io/ansible-devops/](https://ibm-mas.github.io/ansible-devops/)

## Releases
[https://github.com/ibm-mas/ansible-devops/releases](https://github.com/ibm-mas/ansible-devops/releases)
